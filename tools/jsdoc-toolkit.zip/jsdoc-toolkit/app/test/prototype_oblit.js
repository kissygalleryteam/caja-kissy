/** @constructor */
function Article() {
}

Article.prototype = {
	/** instance get title */
	getTitle: function(){
	}
}

/** static get title */
Article.getTitle = function(){
}